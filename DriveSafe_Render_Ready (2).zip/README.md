# DriveSafe — deployment-ready version

This version runs webcam capture and MediaPipe Face Mesh in the visitor's browser. Flask only serves the page, so the cloud server does not need a webcam.

## Run locally

```bash
python -m pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 and allow camera access. MediaPipe scripts/model assets are loaded from jsDelivr, so the browser needs internet access.

## Deploy to Render

1. Push the contents of this folder to your GitHub repository (including `requirements.txt`, `Procfile`, `runtime.txt`, `app.py`, and `templates/index.html`).
2. In Render choose **New + → Web Service**, connect the repository.
3. Runtime: Python. Build command: `pip install -r requirements.txt`. Start command: `gunicorn app:app`.
4. Deploy. Open the HTTPS `onrender.com` URL and allow camera permission.

Camera access works on HTTPS (Render provides HTTPS) or localhost. Camera frames are processed in the browser and are not uploaded to the Flask server by this implementation. This is a student prototype, not a certified driver-safety device.
